import {Controller, Get, Param, Post, Req, Res} from '@nestjs/common';
import {Request, Response} from 'express';
import {ResellerService} from '../service/reseller.service';
import {ApiBody, ApiParam} from "@nestjs/swagger";
import {TransactionService} from "../service/transaction.service";
import { TrannsactionAPIDTO, WebhooksAPIDTO } from 'src/model/Dto/WebhooksAPIDTO';
import { PayloadConstants } from 'src/common/constants/PayloadConstants';


@Controller('/api/resellers')
export class SummaryController {

    constructor(
        private readonly resellerService: ResellerService,
        private readonly transactionService: TransactionService
    ) {
    }

    @Get('/:resellerId/summary')
    @ApiParam({
        name: 'resellerId',
        required: true,
        description: 'Reseller unique identifier',
        schema: {oneOf: [{type: 'string'}]}
    })
    async summary(@Req() req: Request, @Res() res: Response, @Param('resellerId') resellerId) {
        try {
            let resellerData = await this.resellerService.getSummary(resellerId)
            return res.status(200).send(resellerData);
        } catch (e) {
            const {message, error, statusCode} = e?.response || {}
            return res.status(statusCode).json({message, error});
        }
    }


    @Get('/:resellerId/loyaltyTransactions')
    @ApiParam({
        name: 'resellerId',
        required: true,
        description: 'Reseller unique identifier',
        schema: {oneOf: [{type: 'string'}]}
    })
    async loyaltyTransactions(
        @Req() req: Request,
        @Res() res: Response,
        @Param('resellerId') resellerId,
    ) {
        try {
            let result = await this.transactionService.getLoyaltyTransaction(req, resellerId)
            return res.status(200).json(result);
        } catch (e) {
            const {message, error, statusCode} = e?.response || {}
            return res.status(statusCode).json({message, error});

        }
    }
    @Post('/loyaltyTransactions')
    @ApiBody(
        {
            type: TrannsactionAPIDTO,
            description: "The Description for the Post Body. Please look into the DTO for more info.",
            examples: {
                a: {
                    summary: "Payload",
                    description: "Edit the body with actual data",
                    value: PayloadConstants.Transaction_SAMPLE_PAYLOAD as TrannsactionAPIDTO
                }
            }
        }
    )
    async getPointsByDate(
        @Req() req: Request,
        @Res() res: Response,
    ) {
        try {
            let result = await this.transactionService.getPointsByDate(req.body.startDate, req.body.endDate,req.body.selectedResellerIds)
            return res.status(200).json(result);
        } catch (e) {
            const {message, error, statusCode} = e?.response || {}
            return res.status(statusCode).json({message, error});

        }
    }
    @Post('/revenue')
    @ApiBody(
        {
            type: TrannsactionAPIDTO,
            description: "The Description for the Post Body. Please look into the DTO for more info.",
            examples: {
                a: {
                    summary: "Payload",
                    description: "Edit the body with actual data",
                    value: PayloadConstants.Transaction_SAMPLE_PAYLOAD as TrannsactionAPIDTO
                }
            }
        }
    )
    async getRevenueByDate(
        @Req() req: Request,
        @Res() res: Response,
    ) {
        try {
            let result = await this.transactionService.getRevenueByDate(req.body.startDate, req.body.endDate,req.body.selectedResellerIds)
            return res.status(200).json(result);
        } catch (e) {
            const {message, error, statusCode} = e?.response || {}
            return res.status(statusCode).json({message, error});

        }
    }
    @Post('/orders')
    @ApiBody(
        {
            type: TrannsactionAPIDTO,
            description: "The Description for the Post Body. Please look into the DTO for more info.",
            examples: {
                a: {
                    summary: "Payload",
                    description: "Edit the body with actual data",
                    value: PayloadConstants.Transaction_SAMPLE_PAYLOAD as TrannsactionAPIDTO
                }
            }
        }
    )
    async getOrdersByDate(
        @Req() req: Request,
        @Res() res: Response,
    ) {
        try {
            let result = await this.transactionService.getOrdersByDate(req.body.startDate, req.body.endDate,req.body.selectedResellerIds)
            return res.status(200).json(result);
        } catch (e) {
            const {message, error, statusCode} = e?.response || {}
            return res.status(statusCode).json({message, error});

        }
    }
    @Post('/resellers')
    @ApiBody(
        {
            type: TrannsactionAPIDTO,
            description: "The Description for the Post Body. Please look into the DTO for more info.",
            examples: {
                a: {
                    summary: "Payload",
                    description: "Edit the body with actual data",
                    value: PayloadConstants.Transaction_SAMPLE_PAYLOAD as TrannsactionAPIDTO
                }
            }
        }
    )
    async getResellersByDate(
        @Req() req: Request,
        @Res() res: Response,
    ) {
        try {
            let result = await this.transactionService.getRellersByDate(req.body.startDate, req.body.endDate)
            return res.status(200).json(result);
        } catch (e) {
            const {message, error, statusCode} = e?.response || {}
            return res.status(statusCode).json({message, error});

        }
    }
    @Get('/all/:matchString')
    @ApiParam({
        name: 'matchString',
        required: true,
        description: 'Reseller unique identifier',
        schema: {oneOf: [{type: 'string'}]}
    })
    async ResellersWithString(@Res() response: Response,@Param('matchString') matchString) {
        try {
            let res = await this.resellerService.findResellersWithMatch(matchString);
            return response.status(200).json(res);
        } catch (e) {
            console.log(e);
            
            const {message, error, statusCode} = e?.response || {}
            return response.status(statusCode).json({message, error});
        }
    }
    @Post('/brands')
    @ApiBody(
        {
            type: TrannsactionAPIDTO,
            description: "The Description for the Post Body. Please look into the DTO for more info.",
            examples: {
                a: {
                    summary: "Payload",
                    description: "Edit the body with actual data",
                    value: PayloadConstants.Transaction_SAMPLE_PAYLOAD as TrannsactionAPIDTO
                }
            }
        }
    )
    async getBrandsByDate(
        @Req() req: Request,
        @Res() res: Response,
    ) {
        try {
            let result = await this.transactionService.getBrandsByDate(req.body.startDate, req.body.endDate,req.body.selectedResellerIds)
            return res.status(200).json(result);
        } catch (e) {
            const {message, error, statusCode} = e?.response || {}
            return res.status(statusCode).json({message, error});

        }
    }
}

