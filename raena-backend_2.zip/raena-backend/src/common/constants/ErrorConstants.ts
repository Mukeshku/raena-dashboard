export abstract class ErrorConstants {
    static readonly ERROR_MESSAGE_SOMETING_WENT_WRONG: string = 'Something went worng fetching data ';
    static readonly ERROR: string = 'Error'
    static readonly ERROR_RESELLER_NOT_FOUND: string = 'reseller not found';
    static readonly  ERROR_BRAND_NOT_FOUND:  string = 'brand Id not found'
    static readonly ERROR_MESSAGE_MATCH_STRING_LENGTH: string = 'match string length should be greater or  equal 3';
    
}