export abstract class AppConstants {
    static readonly GENERIC_ERROR_MESSAGE: string = 'oops!! Something went wrong. Please try again later.';
}
