export class CalulatePointsGenratedDTO{
    brandId: string;
    tierId: string;
    quantity: number;
    retailPrice: number
}
