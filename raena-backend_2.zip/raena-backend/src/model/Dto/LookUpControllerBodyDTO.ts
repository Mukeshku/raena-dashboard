export class LookUpControllerBodyDTO{
    tierId: string;
    brandId: string;
    multiplier: number;
}
