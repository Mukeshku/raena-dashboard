export class PointsDtoRes {
    pointsGenerated: number;
}