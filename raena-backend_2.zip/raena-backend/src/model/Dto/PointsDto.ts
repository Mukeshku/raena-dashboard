export class PointsDto {
    tierId: string;
    brandId: string; // Never stop trying to reconnect
    quantity: number;
    retailPrice: number;
}