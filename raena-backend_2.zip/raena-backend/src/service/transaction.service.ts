import {Injectable, NotFoundException} from '@nestjs/common';
import {InjectModel} from '@nestjs/mongoose';
import {Model} from 'mongoose';

import {Transactions} from '../model/transaction.model';
import {ErrorConstants} from "../common/constants/ErrorConstants";
import { forEach, result } from 'lodash';

@Injectable()
export class TransactionService {
    constructor(@InjectModel('transactions') private readonly transactionsModel: Model<Transactions>) {
    }

    async getLoyaltyTransaction(req, resellerId) {
        try {
            let {skip, pagelimit, sType}: { skip: number; pagelimit: any; sType: number; } = this.validateRequest(req);
            let response = await this.getPageResult(resellerId, skip, pagelimit, sType);
            let total = await this.getCount(resellerId);
            let meta = {
                hasNext: response.length * skip > total,
                length: response.length,
                total
            }
            return {data: response, meta}
        } catch (e) {
            throw e
        }
    }

    private validateRequest(req: any) {
        let offset = req.query.page;
        let pagesize: any = req.query.pageSize;
        let sort = req.query.sort;
        let sType = 1;
        if (sort == "DESC") {
            sType = -1;
        }
        const pageOptions = {
            page: offset || 0,
            limit: parseInt(pagesize, 10) || 25
        };
        let pageFinal: any = pageOptions.page;
        let pagelimit: any = pageOptions.limit;
        let skip = pageFinal > 0 ? ((pageFinal - 1) * pageOptions.limit) : 0;
        return {skip, pagelimit, sType};
    }

    private async getCount(resellerId: string) {
        return this.countResult(resellerId)
    }

    async findOneAndUpdate(resellerId: string, orderId: string, transaction: any): Promise<any> {
        let product: any;
        try {
            product = await this.transactionsModel.findOneAndUpdate({
                resellerId,
                'data.id': orderId,
            }, transaction, {upsert: true, new: true}).exec();
        } catch (error) {
            throw new NotFoundException(ErrorConstants.ERROR, ErrorConstants.ERROR_RESELLER_NOT_FOUND + ' resellerId ' + resellerId + ' orderId ' + orderId);
        }
        return product;
    }

    async countDocuments(resellerId: string, orderId: string): Promise<any> {
        console.log("transaction", resellerId, orderId);
        let count = 0;
        try {
            count = await this.transactionsModel.count({"resellerId": resellerId, 'data.id': orderId}).exec();
        } catch (error) {
            throw new NotFoundException(ErrorConstants.ERROR, ErrorConstants.ERROR_MESSAGE_SOMETING_WENT_WRONG)
        }
        console.log(count);
        return count;
    }

    async countResult(resellerId: string): Promise<any> {
        let count = 0;
        try {
            count = await this.transactionsModel.count({"resellerId": resellerId}).exec();
        } catch (error) {
            throw new NotFoundException(ErrorConstants.ERROR, ErrorConstants.ERROR_MESSAGE_SOMETING_WENT_WRONG)
        }
        return count;
    }

    async getPageResult(resellerId: string, skip: number, limit: number, sType: any): Promise<any> {
        let product;
        try {
            product = await this.transactionsModel.find({resellerId}, {}).skip(skip).limit(limit)
                .sort({createdAt: sType}).exec();
        } catch (error) {
            throw new NotFoundException(ErrorConstants.ERROR, ErrorConstants.ERROR_MESSAGE_SOMETING_WENT_WRONG)
        }
        if (!product || product.length == 0) {
            throw new NotFoundException(ErrorConstants.ERROR, ErrorConstants.ERROR_RESELLER_NOT_FOUND + ' resellerId ' + resellerId);
        }
        return product;
    }
    async getPointsByDate(startDate: string,endDate:string,resellerIds:string[]): Promise<any>{
        let transactions;
        let matchJson:any 
        if(resellerIds && resellerIds.length>0){
            matchJson = {
                $match : { $and : [ { "createdAt": { $gte: new Date(startDate), $lte: new Date(endDate) }},{ "resellerId": { $in: resellerIds}}]}
            }
        }else{
            matchJson  = {
                $match : { "createdAt": { $gte: new Date(startDate), $lte: new Date(endDate) } }
            }
        }
        try {
            transactions = await this.transactionsModel.collection.aggregate([
                { $project : { "dateparse" : {$substr: ["$createdAt", 0, 10] },"tierId":"$tierId","points":"$points","createdAt":"$createdAt","resellerId":"$resellerId"}},  
                matchJson,     
                { "$group": {
                   "_id": {
                      "date" : "$dateparse",
                       "tierId" :"$tierId"
                   },
                   "pointsCal": { "$sum": "$points" }
                }},
                { "$group": {
                   "_id":  "$_id.date",
                    "tiers":{
                       "$push": { 
                            "tierId": "$_id.tierId",
                            "total": "$pointsCal"
                        },
                   },
                   "total": { "$sum": "$pointsCal" }
                }},
                {   $sort    : { _id : 1 }} 
            ],    
            { "allowDiskUse": true }
            ).toArray();
        } catch (error) {
            throw new NotFoundException(ErrorConstants.ERROR, ErrorConstants.ERROR_MESSAGE_SOMETING_WENT_WRONG)
        }   
        console.log(transactions); 
        return  transactions;   
           
    }
    async getRevenueByDate(startDate: string,endDate:string,resellerIds:string[]): Promise<any>{
        let transactions;
        let matchJson:any 
        if(resellerIds && resellerIds.length>0){
            console.log(resellerIds);
            
            matchJson = {
                $match : { $and : [ { "createdAt": { $gte: new Date(startDate), $lte: new Date(endDate) }},{ "resellerId": { $in: resellerIds}}]}
            }
        }else{
            matchJson  = {
                $match : { "createdAt": { $gte: new Date(startDate), $lte: new Date(endDate) } }
            }
        }
        try {
            transactions = await this.transactionsModel.collection.aggregate([
                { $project : { "dateparse" : {$substr: ["$createdAt", 0, 10] },"tierId":"$tierId","totalAmount":"$data.totalAmount","createdAt":"$createdAt","resellerId":"$resellerId"}},  
                matchJson,     
                { "$group": {
                   "_id": {
                      "date" : "$dateparse",
                       "tierId" :"$tierId"
                   },
                   "amountCal": { "$sum": "$totalAmount" }
                }},
                { "$group": {
                   "_id":  "$_id.date",
                    "tiers":{
                       "$push": { 
                            "tierId": "$_id.tierId",
                            "total": "$amountCal"
                        },
                   },
                   "total": { "$sum": "$amountCal" }
                }},
                {   $sort    : { _id : 1 }} 
            ],    
            { "allowDiskUse": true }
            ).toArray();
        } catch (error) {
            throw new NotFoundException(ErrorConstants.ERROR, ErrorConstants.ERROR_MESSAGE_SOMETING_WENT_WRONG)
        }   
        console.log(transactions); 
        return  transactions;   
           
    }
    async getOrdersByDate(startDate: string,endDate:string,resellerIds:string[]): Promise<any>{
        let transactions;
        let matchJson:any 
        if(resellerIds && resellerIds.length>0){
            matchJson = {
                $match : { $and : [ { "createdAt": { $gte: new Date(startDate), $lte: new Date(endDate) }},{ "resellerId": { $in: resellerIds}}]}
            }
        }else{
            matchJson  = {
                $match : { "createdAt": { $gte: new Date(startDate), $lte: new Date(endDate) } }
            }
        }
        try {
            transactions = await this.transactionsModel.collection.aggregate([
                { $project : { "dateparse" : {$substr: ["$createdAt", 0, 10] },"tierId":"$tierId","orderId":"$data.id", "createdAt":"$createdAt","resellerId":"$resellerId"}},  
                matchJson,    
                { "$group": {
                   "_id": {
                      "date" : "$dateparse",
                       "tierId" :"$tierId",
                       "orderId":"$orderId"
                   },
                   "orderCal": { "$sum": 1 }
                }},
                { "$group": {
                   "_id":  "$_id.date",
                    "tiers":{
                       "$push": { 
                            "orderId": "$_id.orderId",
                            "total": "$orderCal",
                           "tierId":"$_id.tierId"
                        },
                   },
                   "total": { "$sum": "$orderCal" }
                }},
                {   $sort    : { _id : 1 }} 

            ],    
            { "allowDiskUse": true }
            ).toArray();
        } catch (error) {
            throw new NotFoundException(ErrorConstants.ERROR, ErrorConstants.ERROR_MESSAGE_SOMETING_WENT_WRONG)
        } 
        transactions = setTransactions(transactions)  
        console.log(transactions); 
        return  transactions;   
           
    }
    async getRellersByDate(startDate: string,endDate:string): Promise<any>{
        let transactions;
        try {
            transactions = await this.transactionsModel.collection.aggregate([
                { $project : { "dateparse" : {$substr: ["$createdAt", 0, 10] },"tierId":"$tierId","orderId":"$resellerId", "createdAt":"$createdAt"}},  
                {
                    $match : { "createdAt": { $gte: new Date("2021-12-09 10:00:34.228Z"), $lte: new Date("2021-12-29 10:00:34.228Z") } }
                },     
                { "$group": {
                   "_id": {
                      "date" : "$dateparse",
                       "tierId" :"$tierId",
                       "orderId":"$orderId"
                   },
                   "orderCal": { "$sum": 1 }
                }},
                { "$group": {
                   "_id":  "$_id.date",
                    "tiers":{
                       "$push": { 
                            "orderId": "$_id.orderId",
                            "total": "$orderCal",
                           "tierId":"$_id.tierId"
                        },
                   },
                   "total": { "$sum": "$orderCal" }
                }},
                {   $sort    : { _id : 1 }} 

            ],    
            { "allowDiskUse": true }
            ).toArray();
        } catch (error) {
            throw new NotFoundException(ErrorConstants.ERROR, ErrorConstants.ERROR_MESSAGE_SOMETING_WENT_WRONG)
        } 
        transactions = setTransactions(transactions)  
       // console.log(transactions); 
        return  transactions;   
           
    }
    async getBrandsByDate(startDate: string,endDate:string,resellerIds:string[]): Promise<any>{
        let transactions;
        if(!resellerIds){  
            return  new NotFoundException("resellerIds not  present")
        }
        console.log(resellerIds);
        try {
            transactions = await this.transactionsModel.collection.aggregate([
                { $project : { "dateparse" : {$substr: ["$createdAt", 0, 10] },"createdAt":"$createdAt","resellerId":"$resellerId","info":"$data.items"
            }},  
                {
                    $match : { $and : [ { "createdAt": { $gte: new Date(startDate), $lte: new Date(endDate) }},{ "resellerId": { $in: resellerIds}}]}
                },
                
                { "$group": {
                    "_id": "$info.brandName($info.ratailPrice)",
                    "countCal": {"$sum":"$info.ratailPrice" }
                 }},
                 
            ],    
            { "allowDiskUse": true }
            ).toArray();
        } catch (error)  {
            console.log("er",error);
            
            throw new NotFoundException(ErrorConstants.ERROR, ErrorConstants.ERROR_MESSAGE_SOMETING_WENT_WRONG)
        }   
       // console.log(transactions); 
        let data= setBrands(transactions);   
        console.log(data);
        return data 
           
    }

}
function setTransactions(transactions: any) {
  let  results = []
  let  i=0
  transactions?.forEach(element => {
      let tierMap = new Map()
      if (element && element._id){
        element.tiers?.forEach(tier => {   
            let count = tierMap.get(tier.tierId) ||0   
            tierMap.set(tier.tierId,count+1)
        });
        let tierJson = []
        let j=0
        tierMap.forEach(function(value, key){
            tierJson[j++] ={ tierId:key,total:tierMap.get(key)}
        });
        results[i++]  = {
           _id: element._id,
           total:element.total,
           tiers:tierJson    
        } 
      }
  });
  return  results
}

function setBrands(transactions: any): any {
    let tierMap = new Map()
    let  results = []
    let i=0
    console.log(transactions);
    transactions?.forEach(element => {
        if (element && element._id){
          element._id?.forEach(brand => {   
              let val = tierMap.get(brand.brandName) ||0   
              tierMap.set(brand.brandName,val+brand.value)
          });
          
        }
    });
    for (const [key, value] of tierMap.entries()) {
        results[i++] =  {"brandId":key,"count":value};
    }
    return  results
}
